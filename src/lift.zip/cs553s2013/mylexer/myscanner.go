package mylexer

import (
	  "github.com/proebsting/cs553s2013/lexer"
	 //"fmt"
  )


func Lexer(input string, out chan<-lexer.Token){
       var output string
       var token Token
       follow :=0
      ext := 0
      match_star := false
       length := len(input)
       lines := 1 
       columns := 1
       if length == 0 {
	    //fmt.Println("Empty string condition evaluated?")
	    token = Token{value:"<EOF>", location:0, line:1, column:1, enum:lexer.EOF}
	    out <- token
	    //fmt.Println("The value of the token is: ", token)
	    return
      }
      
      i := 0
      for i < length {
	//fmt.Println("The value of i is: " , i, " and length is " ,length)
	 //code to keep track of line numbers
	 //fmt.Println("The value of i is: " , i, " and length is " ,length, " having read up to line_number ", lines)
	 for input[i] == 10 || input[i] == ' ' || input[i] == 9 || input[i] == 13{
                if input[i] == 10 {
                        lines++
                        columns = 1
          //              fmt.Println("Is this ever executed? ")
                        i++
                }       else {
                        columns++
                        i++
                }
                //safety check
                if !(i < length){
			token = Token{value:"<EOF>", location:0, line: lines, column: columns, enum:lexer.EOF}
			
			out<-token
	//		fmt.Println("The value of the token is: ", token)
			return
		}
        }
	 //fmt.Println("We passed space checking loop")
	 if ! (i < length) {
	   //   fmt.Println("Perhaps the issue happens here! ")
	      token = Token{value:"<EOF>", location:0, line: lines, column: columns, enum:lexer.EOF}
		out<-token
		//fmt.Println("The value of the token is: ", token)
		return
	 }
	 tok, size, match := lexer.Operator(input[i:])
	 //fmt.Println("Just about to evaluate letter comparison code with match value: ", match , " on input ", input[i:], "and position ", i)
	 if  IsALetter(input[i]) {
	   
	   //fmt.Println("Did you notice this? ")
	    output = Reading_Identifier(input[i:])
	    //means we've read an identifier, on line lines and column columns
	   // fmt.Println("Read an identifier")
	    lexed, paired := lexer.Keyword(output)
	    if paired {
		  token = Token{value: output, location:0, line: lines, column: columns, enum:lexed}
		  out<- token
	    } else {
	    token = Token{value: output, location:0, line: lines, column: columns, enum:lexer.IDENT}
	    out<-token
	    }
	    //out<-token
	    columns += len(output)
	    //fmt.Println("The token is as follows: ", token)
	    i += len(output)
	    //fmt.Println("Code execution reaches here! ")
	    //safety check
	    continue
	 } else if IsADigit(input[i]) {
	      output = IsAnId(input[i])
	      //condition to check if we are at end of input
	      if len(input[i:]) < 2 {
		token = Token{value: output, location:0, line: lines, column: columns, enum:lexer.INTEGER}
		//fmt.Println("The value of the token is: ", token)
	        out<-token
		//possible bug in the following line of code
		columns++
	        token = Token{value:"<EOF>", location:0, line: lines, column: columns, enum:lexer.EOF}
	        out<-token
	        //fmt.Println("The value of the token is: ", token)
	        return
	      }
	      //modify Reading_Number to return type as well
	      number, bel := Reading_Number(input[i:])
	      output = number
	      //fmt.Println("Value of number token is: ", output)
	      token = Token{value: output, location:0, line: lines, column: columns, enum:bel}
	      columns += len(output)
	      i += len(output)
	      out <- token
	      //fmt.Println("The value of the token is: ", token)
	      continue
	  } else if input[i] == '"' {
	    //we are reading a string
	    //fmt.Println("Now reading  string with i equaling and input ", i, input)
	    if len(input[i:]) < 2 {
	    //this means error token at position i, return error
	      token = Token{value: "\"", location:0, line:lines, column: columns, enum:lexer.ERROR}
	      //fmt.Println("The value of the token is: ", token)
	      out <- token
	      return
	    }
	    //fmt.Println("Input to Reading_String method is, ", input[i+1:], i)
	    output = Reading_String(input[i+1:])
	    //fmt.Println("Token is a string with value ", output)
	    j := 0
	    error_flag := 0
		for j < len(output) {
		      if output[j] == '"' {
			error_flag++
		      }
		      j++
		}

		if error_flag == 1 {
		    //no matching quote found in string, return error
		    token = Token{value: output, location:0, line:lines, column: columns, enum:lexer.ERROR}
		    out <- token
		//fmt.Println("The value of the token is: ", token)
		    return
		}
		token = Token{value: output, location:0, line: lines, column: columns, enum:lexer.STRING}
		//fmt.Println("The value of the token found is: ", token)
		j = 0
			for j < len(output) {
			    if output[j] == 10 {
				  lines++
				  columns = 1
			    } else {
			      columns++ 
			    }
			    j++
			}
		
		out <- token
		//fmt.Println("The value of the token is just before continuing: ", token)
		i += len(output)
		//fmt.Println("The value of i just before continuing: ", i, " whilst length equals: ", length)
		//do this for safety reasons
		/*
		if( i == length - 1){
		    token = Token{value:"<EOF>", location:0, line: lines, column: columns, enum:lexer.EOF}
		  //  fmt.Println("The value of the token found is: ", token)
		    out <- token
		    return
		}*/
		continue
	  } else if  match {
	  //we are reading an operator, or possibly a comments
	  //fmt.Println("In operator evaluating code: ")
	  if i < (len(input) - 1){
		    follow, ext, match_star = lexer.Operator(input[i+1:])
		}    
	  if (tok == lexer.LPAREN) && follow == lexer.STAR {
		//possibly reading a comment at this stage
		//fmt.Println("We have read an LParen")
		
		
			//means we are reading a comment
			if match_star {
			ext++
			}
		//	fmt.Println("Now reading a comment on input value ", input[i:])
			output = Reading_Comment(input[i:])
			//fmt.Println("Exited comment reading function with output value equaling: " , output)
			if output == "bad comment" {
			  token = Token{value: output, location:0, line:lines, column: columns, enum:lexer.ERROR}
			  out<-token
			  //fmt.Println("The value of the token is: ", token)
			  return
			}
			//fix the lines column issue
			j := 0
			for j < len(output) {
			    if output[j] == 10 {
				  lines++
				  columns = 1
			    }  else {
			      columns++ 
			    }
			    j++
			}
			//fmt.Println("Token is a comment with value: ", output)
			i += len(output)
			//fmt.Println("The value of i is: " , i, " and length is " ,length)
			if i == length {
			    token = Token{value:"<EOF>", location:0, line:lines, column:columns, enum:lexer.EOF}
			  //  fmt.Println("The value of the token is: ", token)
			    out <- token
			    return
			}
	 } else {
	
		output = input[i:i+size]
		//fmt.Println("Evaluating operator ", output, " right now for token number", tok)
		
		token = Token{value: output, location:0, line: lines, column: columns, enum:tok}
		out <- token
		//fmt.Println("The value of the token is: ", token)
		columns += size
		i += size
		//fmt.Println("The value of i is: " , i, " and length is " ,length)
		if i == length {
			    token = Token{value:"<EOF>", location:0, line:lines, column:columns, enum:lexer.EOF}
		//	    fmt.Println("The value of the token is: ", token)
			    out <- token
			    return
			}
		//out <- token
		//fmt.Println("Token is an operator with value: ", output)
		//before hitting continue, evaluate if we are at end of input
		continue
	    }
	   
	} else {
	  //means there is an unrecognized token!
	    token = Token{value:"-1", location:0, line:lines, column:columns, enum:lexer.ERROR}
	    //fmt.Println("The value of the token found is: " ,token, "and its value in unicode is " , input[i])
	    out <- token
	    return
	}
	  
	  
      }
      
      //reaching this region means we are at end of input
      token = Token{value:"<EOF>", location:0, line:lines, column:columns, enum:lexer.EOF}
      //fmt.Println("The value of the token is: ", token)
      out <- token
}
      
       
       